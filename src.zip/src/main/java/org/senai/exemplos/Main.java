package org.senai.exemplos;


public class Main {
    public static void main(String[] args) {
        //teste
        Funcionario func1 = new Funcionario("Priscila", "TI");
        func1.mostrarDados();
        Gerente func2 = new Gerente("Keyla", "2500");
        func2.mostrarBonus();

    }
}