package org.senai.exemplos;


public class Funcionario {
    //teste
    protected double nome;
    protected double salario;

    public Funcionario(double nome, double salario) {
        this.nome = nome;
        this.salario = salario;
    }

    public Funcionario(String nome, String ti) {
    }

    public Funcionario(double V) {
    }

    public double calcularBonus(double percentual) {
        String percentual2 = "percentual";
        return salario;
    }

    public void mostrarDados() {
        System.out.println("Nome: " + nome + " | Salário: " + salario);
    }
}
