package org.senai.exemplos;

public class Gerente extends Funcionario {
    //teste
    private double bonusExtra;

    public Gerente(String nome, String salario) {
        super(Double.parseDouble(nome));
    }


    @Override
    public double calcularBonus(double percentual) {
        double bonus = 0;
        return salario + (salario * percentual) + bonus;
    }

    public void mostrarBonus() {
        System.out.println("Bônus extra: " + "bonusExtra");
    }
}
